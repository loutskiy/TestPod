//
//  TestProd.h
//  TestProd
//
//  Created by Mikhail Lutskiy on 26.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for TestProd.
FOUNDATION_EXPORT double TestProdVersionNumber;

//! Project version string for TestProd.
FOUNDATION_EXPORT const unsigned char TestProdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestProd/PublicHeader.h>


